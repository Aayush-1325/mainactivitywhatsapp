package com.example.authentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    Button btn;
    EditText email;
    EditText pass1;
    TextView tv1;
    ProgressDialog pd;
    FirebaseAuth firebaseAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        firebaseAuth=FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser()!=null){
            finish();
            startActivity(new Intent(LoginActivity.this,profileActivity.class));
        }

        pd= new ProgressDialog(this);
        btn=(Button)findViewById(R.id.register1);
        email=(EditText)findViewById(R.id.mail1);
        pass1=(EditText)findViewById(R.id.password1);
        tv1=(TextView) findViewById(R.id.textView1);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Userlogin();
            }
        });
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                startActivity(new Intent(LoginActivity.this,MainActivity.class));


            }
        });

    }
    private void Userlogin(){
        String mail=email.getText().toString().trim();
        String pass=pass1.getText().toString().trim();

        if((TextUtils.isEmpty(mail)) && (TextUtils.isEmpty(pass))){
            Toast.makeText(this,"you should enter complete details",Toast.LENGTH_LONG).show();
            return;
        }
        pd.setMessage("Registering User....");
        pd.show();
        firebaseAuth.signInWithEmailAndPassword(mail,pass)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        pd.dismiss();
                        if(task.isSuccessful()){
                            finish();
                            startActivity(new Intent(LoginActivity.this,profileActivity.class));
                        }


                    }
                });
    }
}
